/**
 * 
 */
/**
 * 
 */
module Atividade_class_abstract {
}